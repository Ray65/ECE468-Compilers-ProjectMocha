/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 14 "src/parser.yy" /* yacc.c:339  */

  #include <stdio.h>
  #include <iostream>
  #include <stack>
  #include <string>
  #include <vector>
  #include <map>
  #include <list>
  #include <set>
  #include "../src/SymbolTable.h"

  int blockCounter = 0;
  int elseCounter = 0;
  int ifCounter = 0;
  int printVDnum = 0;
  bool isLivenessChanged = false;
  
  std::vector<CFGEntry*> CFGStmtVect;
  std::vector<std::string> finalIRvector;
  std::vector<std::string> tempIRvector;
  extern std::vector<std::string> IRcodeVector;
  //Offset Counter
  int offset = 0;
  //int it = 0;
  std::vector<CodeObject*> coVect;

  void yyerror(const char* str){}
  extern int yylex();
  extern char* yytext;
  SymbolTable* root; 
  VectorTable* vectRoot;
  
  std::stack<SymbolTable *> symtabStack;
  std::stack<VectorTable *> vectTabStack;
  std::stack<ASTNode*> ifStack;
  std::vector<ASTNode*> FuncVect;
  

  std::string genScope(){
    return "BLOCK " + std::to_string((long long)++blockCounter);
  }


  void printInOrder(ASTNode* node){
		if(node == NULL)
			return;
		printInOrder(node->leftChild);
		//std::cout<<"Node token is: "<<node->token<<"        Token type is: "<<node->tokType<<std::endl;
		printInOrder(node->rightChild);
	}



std::vector<std::string> returnSplitVect(std::string strToSplit)
{	
	std::string delimiter = " ";
	std::string token;
	std::vector<std::string> indivStrVect;
	
    	size_t prev = 0, pos = 0;
	do{
        	pos = strToSplit.find(delimiter, prev);
        	if (pos == std::string::npos) pos = strToSplit.length();
        		token = strToSplit.substr(prev, pos-prev);
        	if (!token.empty()) indivStrVect.push_back(token);
       	 		prev = pos + delimiter.length();
    	}while (pos < strToSplit.length() && prev < strToSplit.length());

	return indivStrVect;
}

//For CFG
std::vector<CFGEntry*> assignCFGID(std::vector<std::string> finalIRVect){
	//std::vector<CFGEntry> CFGStmtVect;	
	for (int i = 0; i < finalIRVect.size(); i++){
		CFGEntry* currCFG = new CFGEntry(finalIRVect[i]);
		currCFG->StmtID = i;
		CFGStmtVect.push_back(currCFG);
		currCFG->next.push_back(i+1);
		
	}
	return CFGStmtVect;
	

}

std::vector<CFGEntry*> buildCFG(std::vector<CFGEntry*> CFGStmtVect){
	//Assigning JumpLabels
	for(int i=0; i<CFGStmtVect.size(); i++){
		std::string jumpLabel;
		std::string currStmt = CFGStmtVect[i]->InstructStmt;
		std::vector<std::string> SplitText = returnSplitVect(currStmt);
		if((SplitText[0] == ";GTI")||(SplitText[0] == ";LTI")||(SplitText[0] == ";GEI")||(SplitText[0] == ";LEI")||(SplitText[0] == ";EQI")||(SplitText[0] == ";NEI")||(SplitText[0] == ";GTF")||(SplitText[0] == ";LTF")||(SplitText[0] == ";GEF")||(SplitText[0] == ";LEF")||(SplitText[0] == ";EQF")||(SplitText[0] == ";NEF")){
			
				//std::cout<<"FOUND A COMPARISON!!!"<<std::endl; //test string
				jumpLabel = SplitText[3];
				CFGStmtVect[i]->JumpLabel = jumpLabel;
				//std::cout<<"Jump Label for stmt "<<i<<" is --------> "<<CFGStmtVect[i]->JumpLabel<<std::endl; //test string
		

		}

		if(SplitText[0] == ";JUMP"){
			//std::cout<<"FOUND A JUMP!!!"<<std::endl; //test string
			jumpLabel = SplitText[1];
			CFGStmtVect[i]->JumpLabel = jumpLabel;
			//std::cout<<"Jump Label for stmt "<<i<<" is --------> "<<CFGStmtVect[i]->JumpLabel<<std::endl; //test string

		}

	}

	//Linking Nexts
	for(int j=0; j<CFGStmtVect.size(); j++){
		std::string currStmt = CFGStmtVect[j]->InstructStmt;
		std::vector<std::string> SplitText = returnSplitVect(currStmt);
		if((CFGStmtVect[j]->JumpLabel) != "\0"){
			//std::cout<<"JUMP LABEL for "<<j<<" is not empty!!"<<std::endl; //test string
			std::string labelString = ";LABEL "+(CFGStmtVect[j]->JumpLabel);
			for(int k=0; k<CFGStmtVect.size(); k++){
				std::string currStmt2 = CFGStmtVect[k]->InstructStmt;
				if(currStmt2 == labelString){
					if((SplitText[0] == ";GTI")||(SplitText[0] == ";LTI")||(SplitText[0] == ";GEI")||(SplitText[0] == ";LEI")||(SplitText[0] == ";EQI")||(SplitText[0] == ";NEI")||(SplitText[0] == ";GTF")||(SplitText[0] == ";LTF")||(SplitText[0] == ";GEF")||(SplitText[0] == ";LEF")||(SplitText[0] == ";EQF")||(SplitText[0] == ";NEF")){
						CFGStmtVect[j]->next.push_back(k);

					}

				if(SplitText[0] == ";JUMP"){
						CFGStmtVect[j]->next[0] = k;			
				}


				}
			}
	
		}
			
		
	}
	//std::cout<<"SIZE OF CFGVECT ----------- "<<CFGStmtVect.size()<<std::endl;
	//Linking Prevs
	
	for(int j=0; j<CFGStmtVect.size(); j++){
		int nextLen = CFGStmtVect[j]->next.size();
		for(int k = 0; k < nextLen; k++){
			int nextNum = CFGStmtVect[j]->next[k];
			if(nextNum >= CFGStmtVect.size())
			{
				continue;
			}
			CFGStmtVect[nextNum]->prev.push_back(j);
			//std::cout<<"Prev push success!"<<std::endl;		
		}
	}
	

	return CFGStmtVect;	
}


std::vector<CFGEntry*> generateGenKill(std::vector<CFGEntry*> CFGStmtVect){
	for(int i=0; i < CFGStmtVect.size(); i++){
		std::string currStmt = CFGStmtVect[i]->InstructStmt;
		std::vector<std::string> SplitText = returnSplitVect(currStmt);

		//Checks for STORE
		if((SplitText[0] == ";STOREI") || (SplitText[0] == ";STOREF")){
			CFGStmtVect[i]->genSet.push_back(SplitText[1]);	//Adding to genSet
			CFGStmtVect[i]->killSet.push_back(SplitText[2]); //Adding to killSet
			
		}

		//Checks for READ
		else if((SplitText[0] == ";READI") || (SplitText[0] == ";READF")){			
			CFGStmtVect[i]->killSet.push_back(SplitText[1]); //Adding to killSet			
		}

		//Checks for WRITE
		else if((SplitText[0] == ";WRITEI") || (SplitText[0] == ";WRITEF") || (SplitText[0] == ";WRITES")){			
			CFGStmtVect[i]->genSet.push_back(SplitText[1]); //Adding to genSet			
		}

		//Checks for PUSH
		else if(SplitText[0] == ";PUSH"){
			if(SplitText.size() == 2)
			{						
				CFGStmtVect[i]->genSet.push_back(SplitText[1]); //Adding to genSet	
			}		
		}

		//Checks for POP
		else if(SplitText[0] == ";POP"){
			if(SplitText.size() == 2)
			{			
				CFGStmtVect[i]->killSet.push_back(SplitText[1]); //Adding to killSet			
			}
		}

		//Checks for Arithmetic Operations
		else if((SplitText[0] == ";ADDI") || (SplitText[0] == ";ADDF") || (SplitText[0] == ";SUBI") || (SplitText[0] == ";SUBF") || (SplitText[0] == ";MULI") || (SplitText[0] == ";MULF") || (SplitText[0] == ";DIVI") || (SplitText[0] == ";DIVF")){
			CFGStmtVect[i]->genSet.push_back(SplitText[1]);	//Adding to genSet
			CFGStmtVect[i]->genSet.push_back(SplitText[2]);	//Adding to genSet
			CFGStmtVect[i]->killSet.push_back(SplitText[3]); //Adding to killSet
			
		}

		//Checks for Comparison 
		else if((SplitText[0] == ";GTI")||(SplitText[0] == ";LTI")||(SplitText[0] == ";GEI")||(SplitText[0] == ";LEI")||(SplitText[0] == ";EQI")||(SplitText[0] == ";NEI")||(SplitText[0] == ";GTF")||(SplitText[0] == ";LTF")||(SplitText[0] == ";GEF")||(SplitText[0] == ";LEF")||(SplitText[0] == ";EQF")||(SplitText[0] == ";NEF")){
			CFGStmtVect[i]->genSet.push_back(SplitText[1]);	//Adding to genSet
			CFGStmtVect[i]->genSet.push_back(SplitText[2]);	//Adding to genSet

		}

		//Checks for Function call
		else if((SplitText[0] == ";JSR")){
			SymbolTable* currentTab;
		 	currentTab = symtabStack.top();
		              while(currentTab != NULL){		                
		                  if(currentTab->scope == "GLOBAL"){
					int ordTabSize = currentTab->ordered_table.size();
					for(int x = 0; x < ordTabSize; x++){
						CFGStmtVect[i]->genSet.push_back(currentTab->ordered_table[x]->var_name);	//Adding to genSet
					}				
				
				}

			currentTab = currentTab->parent;
			}

		}


	}


	return CFGStmtVect;
}

//Computing Liveness
std::vector<CFGEntry*> analyzeLiveness(std::vector<CFGEntry*> CFGStmtVect){
	isLivenessChanged = false;
	int numCFGentries = CFGStmtVect.size();
	for(int i = numCFGentries-2; i >= 0; i--){
	
		std::set<std::string> prevLiveIN = CFGStmtVect[i]->liveIN;
		std::set<std::string> prevLiveOUT = CFGStmtVect[i]->liveOUT;


	//Computing LIVE-OUT
		for(int j = 0; j < CFGStmtVect[i]->next.size(); j++){
			std::set<std::string> tempSet = CFGStmtVect[CFGStmtVect[i]->next[j]]->liveIN;
			for(std::set<std::string>::iterator it = tempSet.begin(); it != tempSet.end(); it++){
				CFGStmtVect[i]->liveOUT.insert(*it);
			}
		}
	//Computing LIVE-IN
		//Adding LIVE-OUT
		std::set<std::string> tempLiveOUT = CFGStmtVect[i]->liveOUT;	
		for(std::set<std::string>::iterator it = tempLiveOUT.begin(); it != tempLiveOUT.end(); it++){
			CFGStmtVect[i]->liveIN.insert(*it);
		}

		//Minusing KILL-set
		for(int j = 0; j < CFGStmtVect[i]->killSet.size(); j++){	
			CFGStmtVect[i]->liveIN.erase(CFGStmtVect[i]->killSet[j]);
		}

		//Adding GEN-set
		for(int j = 0; j < CFGStmtVect[i]->genSet.size(); j++){	
			CFGStmtVect[i]->liveIN.insert(CFGStmtVect[i]->genSet[j]);
		}

		
		if((prevLiveIN != CFGStmtVect[i]->liveIN) || (prevLiveOUT != CFGStmtVect[i]->liveOUT)){
			isLivenessChanged = true;
		}

	}

	return CFGStmtVect;
}


 
/*
  void yyerror(const char* str){}
  extern int yylex();
  extern char* yytext;
  SymbolTable* root; 
  VectorTable* vectRoot;
  
  std::stack<SymbolTable *> symtabStack;
  std::stack<VectorTable *> vectTabStack;
  std::stack<ASTNode*> ifStack;
  std::vector<ASTNode*> FuncVect;*/

#line 363 "generated/parser.cpp" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "parser.hpp".  */
#ifndef YY_YY_GENERATED_PARSER_HPP_INCLUDED
# define YY_YY_GENERATED_PARSER_HPP_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 1 "src/parser.yy" /* yacc.c:355  */

  #include <stdio.h>
  #include <iostream>
  #include <stack>
  #include <string>
  #include <sstream>
  #include <vector>
  #include <map>
  #include <list>
  #include <typeinfo>
  #include "../src/SymbolTable.h"


#line 407 "generated/parser.cpp" /* yacc.c:355  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    INTLITERAL = 258,
    FLOATLITERAL = 259,
    STRINGLITERAL = 260,
    IDENTIFIER = 261,
    PROGRAM = 262,
    SEMICOLON = 263,
    _BEGIN = 264,
    END = 265,
    FUNCTION = 266,
    READ = 267,
    WRITE = 268,
    IF = 269,
    ELSE = 270,
    ENDIF = 271,
    WHILE = 272,
    ENDWHILE = 273,
    RETURN = 274,
    INT = 275,
    VOID = 276,
    STRING = 277,
    FLOAT = 278,
    TRUE = 279,
    FALSE = 280,
    COLONEQUAL = 281,
    PLUS = 282,
    MINUS = 283,
    ASTERISK = 284,
    FWDSLASH = 285,
    EQUAL = 286,
    NOTEQUAL = 287,
    LESSTHAN = 288,
    GREATERTHAN = 289,
    OPENPARAN = 290,
    CLOSEPARAN = 291,
    COMMA = 292,
    LESSTHANEQUAL = 293,
    GREATERTHANEQUAL = 294
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 311 "src/parser.yy" /* yacc.c:355  */

  int tok;
  std::string* sstr;
  std::list<std::string>* slist;
  ASTNode* ASTPtr;
  Arithmetic* ArithPtr;
  std::vector<ASTNode*>* ASTPtrVectPtr;
  
 

#line 470 "generated/parser.cpp" /* yacc.c:355  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_GENERATED_PARSER_HPP_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 487 "generated/parser.cpp" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  5
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   128

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  40
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  52
/* YYNRULES -- Number of rules.  */
#define YYNRULES  84
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  145

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   294

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   339,   339,   338,   450,   452,   454,   454,   454,   457,
     475,   482,   502,   502,   504,   505,   507,   509,   510,   513,
     513,   515,   530,   530,   533,   533,   536,   559,   563,   535,
     648,   656,   657,   659,   660,   663,   666,   667,   670,   673,
     676,   678,   692,   755,   822,   825,   839,   857,   859,   873,
     890,   892,   892,   894,   901,   901,   902,   903,   905,   906,
     937,   943,   950,   951,   952,   953,   957,   967,   956,   985,
     985,   987,   989,   994,  1000,  1006,  1007,  1008,  1009,  1010,
    1011,  1015,  1014,  1032,  1033
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "INTLITERAL", "FLOATLITERAL",
  "STRINGLITERAL", "IDENTIFIER", "PROGRAM", "SEMICOLON", "_BEGIN", "END",
  "FUNCTION", "READ", "WRITE", "IF", "ELSE", "ENDIF", "WHILE", "ENDWHILE",
  "RETURN", "INT", "VOID", "STRING", "FLOAT", "TRUE", "FALSE",
  "COLONEQUAL", "PLUS", "MINUS", "ASTERISK", "FWDSLASH", "EQUAL",
  "NOTEQUAL", "LESSTHAN", "GREATERTHAN", "OPENPARAN", "CLOSEPARAN",
  "COMMA", "LESSTHANEQUAL", "GREATERTHANEQUAL", "$accept", "program",
  "$@1", "id", "pgm_body", "decl", "string_decl", "str", "var_decl",
  "var_type", "any_type", "id_list", "id_tail", "param_decl_list",
  "param_decl", "param_decl_tail", "func_declarations", "func_decl", "$@2",
  "$@3", "$@4", "func_body", "stmt_list", "stmt", "base_stmt",
  "assign_stmt", "assign_expr", "read_stmt", "write_stmt", "return_stmt",
  "expr", "expr_prefix", "factor", "factor_prefix", "postfix_expr",
  "call_expr", "expr_list", "expr_list_tail", "primary", "addop", "mulop",
  "if_stmt", "$@5", "$@6", "else_part", "$@7", "cond", "compop",
  "while_stmt", "$@8", "control_stmt", "loop_stmt", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294
};
# endif

#define YYPACT_NINF -59

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-59)))

#define YYTABLE_NINF -56

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int8 yypact[] =
{
      -2,    18,    28,   -59,     4,   -59,   -59,    16,   -59,    18,
     -59,    31,    -4,    16,    16,    18,    17,   -59,    -6,   -59,
      -4,   -59,   -59,    20,    47,    51,   -59,   -59,    18,   -59,
      18,   -59,   -59,   -59,    52,    24,    20,   -59,   -59,   -59,
      10,    18,    25,    26,   -59,    53,    10,   -59,   -59,    26,
      16,   -59,     6,   -59,    29,    30,    35,    36,   -59,    40,
     -59,     6,   -59,   -59,    64,   -59,   -59,   -59,   -59,   -59,
     -59,   -59,    63,    18,    18,    -3,    -3,    68,   -59,   -59,
     -59,   -59,   -59,    41,    42,   -59,   -59,    13,    43,    45,
     -59,     7,     5,   -59,    74,    75,   -59,   -59,   -59,   -59,
     -59,   -59,   -59,   -59,   -59,   -59,   -59,   -59,   -59,   -59,
     -59,    49,    19,   -59,   -59,   -59,   -59,   -59,    16,    16,
      50,    54,   -59,   -59,   -59,     6,     6,   -59,    55,    58,
     -59,    69,   -59,   -59,   -59,    73,   -59,    55,   -59,    79,
     -59,    16,   -59,     6,   -59
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     4,     0,     1,     2,     8,    13,     0,
      12,     0,    25,     8,     8,     0,     0,     3,     0,     5,
      25,     6,     7,    18,     0,     0,    15,    14,     0,    24,
       0,    16,    11,    10,     0,     0,    18,     9,    26,    17,
      20,     0,     0,    23,    21,     0,     0,    19,    27,    23,
       8,    22,    32,    28,     0,     0,     0,     0,    47,     0,
      30,    32,    33,    36,     0,    37,    38,    83,    34,    84,
      39,    35,     0,     0,     0,    47,    47,     0,    50,    47,
      31,    40,    29,     0,     0,    73,    74,     0,     0,     0,
      44,    45,     0,    41,     0,     0,    77,    78,    75,    76,
      79,    80,    47,    66,    81,    62,    63,    46,    60,    61,
      47,    59,    48,    52,    51,    42,    43,    72,     8,     8,
       0,    47,    64,    65,    49,    32,    32,    58,    57,     0,
      67,     0,    47,    54,    53,    71,    82,    57,    69,     0,
      56,     8,    68,    32,    70
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int8 yypgoto[] =
{
     -59,   -59,   -59,     1,   -59,   -13,   -59,   -59,   -59,   -14,
     -59,   -20,    60,   -59,    56,    48,    71,   -59,   -59,   -59,
     -59,   -59,   -58,   -59,   -59,   -59,   -59,   -59,   -59,   -59,
     -52,   -59,   -59,   -59,   -59,   -59,   -59,   -48,   -59,   -59,
     -59,   -59,   -59,   -59,   -59,   -59,    22,   -59,   -59,   -59,
     -59,   -59
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     2,     7,    59,    11,    12,    13,    34,    14,    15,
      28,    24,    31,    42,    43,    47,    19,    20,    40,    50,
      72,    53,    60,    61,    62,    63,    64,    65,    66,    67,
      87,    78,    91,    92,   112,   113,   129,   133,   114,   107,
     124,    68,   118,   135,   139,   141,    88,   102,    69,   119,
      70,    71
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      21,    22,     4,    80,    27,     1,    77,    18,   108,   109,
      16,     3,     3,     6,     8,    26,    23,    10,    54,    55,
      56,    85,    86,    57,     3,    58,    41,    93,     5,    35,
       8,    36,    41,    10,   105,   106,     8,    52,     9,    10,
     110,    17,    44,    25,    96,    97,    98,    99,   122,   123,
     117,   100,   101,    83,    84,    32,    33,    30,   120,    38,
      37,    45,    48,    46,    73,    74,    79,   130,   131,   128,
      75,    76,    81,    82,    23,    23,    90,    94,    95,   103,
     137,   104,   115,   116,   121,   144,   127,   136,   138,   140,
     -55,    29,   132,   111,   134,   142,    39,    51,    89,     0,
       0,     0,    49,     0,     0,   125,   126,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   143
};

static const yytype_int16 yycheck[] =
{
      13,    14,     1,    61,    18,     7,    58,    11,     3,     4,
       9,     6,     6,     9,    20,    21,    15,    23,    12,    13,
      14,    24,    25,    17,     6,    19,    40,    79,     0,    28,
      20,    30,    46,    23,    27,    28,    20,    50,    22,    23,
      35,    10,    41,    26,    31,    32,    33,    34,    29,    30,
     102,    38,    39,    73,    74,     8,     5,    37,   110,    35,
       8,    36,     9,    37,    35,    35,    26,   125,   126,   121,
      35,    35,     8,    10,    73,    74,     8,    36,    36,    36,
     132,    36,     8,     8,    35,   143,    36,    18,    15,   137,
      36,    20,    37,    92,    36,    16,    36,    49,    76,    -1,
      -1,    -1,    46,    -1,    -1,   118,   119,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   141
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     7,    41,     6,    43,     0,     9,    42,    20,    22,
      23,    44,    45,    46,    48,    49,    43,    10,    11,    56,
      57,    45,    45,    43,    51,    26,    21,    49,    50,    56,
      37,    52,     8,     5,    47,    43,    43,     8,    35,    52,
      58,    49,    53,    54,    43,    36,    37,    55,     9,    54,
      59,    55,    45,    61,    12,    13,    14,    17,    19,    43,
      62,    63,    64,    65,    66,    67,    68,    69,    81,    88,
      90,    91,    60,    35,    35,    35,    35,    70,    71,    26,
      62,     8,    10,    51,    51,    24,    25,    70,    86,    86,
       8,    72,    73,    70,    36,    36,    31,    32,    33,    34,
      38,    39,    87,    36,    36,    27,    28,    79,     3,     4,
      35,    43,    74,    75,    78,     8,     8,    70,    82,    89,
      70,    35,    29,    30,    80,    45,    45,    36,    70,    76,
      62,    62,    37,    77,    36,    83,    18,    70,    15,    84,
      77,    85,    16,    45,    62
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    40,    42,    41,    43,    44,    45,    45,    45,    46,
      47,    48,    49,    49,    50,    50,    51,    52,    52,    53,
      53,    54,    55,    55,    56,    56,    58,    59,    60,    57,
      61,    62,    62,    63,    63,    63,    64,    64,    64,    64,
      65,    66,    67,    68,    69,    70,    71,    71,    72,    73,
      73,    74,    74,    75,    76,    76,    77,    77,    78,    78,
      78,    78,    79,    79,    80,    80,    82,    83,    81,    85,
      84,    84,    86,    86,    86,    87,    87,    87,    87,    87,
      87,    89,    88,    90,    91
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     6,     1,     2,     2,     2,     0,     5,
       1,     3,     1,     1,     1,     1,     2,     3,     0,     2,
       0,     2,     3,     0,     2,     0,     0,     0,     0,    12,
       2,     2,     0,     1,     1,     1,     1,     1,     1,     1,
       2,     3,     5,     5,     3,     2,     3,     0,     2,     3,
       0,     1,     1,     4,     2,     0,     3,     0,     3,     1,
       1,     1,     1,     1,     1,     1,     0,     0,    10,     0,
       4,     0,     3,     1,     1,     1,     1,     1,     1,     1,
       1,     0,     8,     1,     1
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 339 "src/parser.yy" /* yacc.c:1646  */
    {
                    //Symbol Table
		    root = new SymbolTable("GLOBAL", NULL); 
                    symtabStack.push(root);
		    
		    //Vector Table
		    vectRoot = new VectorTable("GLOBAL", NULL);
		    vectTabStack.push(vectRoot);
			 
                  }
#line 1682 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 3:
#line 350 "src/parser.yy" /* yacc.c:1646  */
    {

		    VectorTable* currVectTabTOP = vectTabStack.top();
		    std::string funcJsr;
		    //funcJsr = funcJsr + ";JSR FUNC_"+currVectTabTOP->vectTabName;
		    finalIRvector.insert(finalIRvector.begin(),";HALT"); 
		    funcJsr = funcJsr + ";JSR FUNC_main"; 
   		    finalIRvector.insert(finalIRvector.begin(),funcJsr);

		    finalIRvector.insert(finalIRvector.begin(),";PUSHREGS");
		    finalIRvector.insert(finalIRvector.begin(),";PUSH");			
		    finalIRvector.insert(finalIRvector.begin(),";IR CODE");		

		    //VectorTable* currVectTabTOP = vectTabStack.top();
		    currVectTabTOP->PrintIRcodeVector(finalIRvector);

		    //Looping to create & number CFGEntries
		    CFGStmtVect = assignCFGID(finalIRvector);

		    //Doing Next & Prev Linking		    
		    CFGStmtVect = buildCFG(CFGStmtVect);
		    /*
			for(int k=0; k<CFGStmtVect.size(); k++){
				int lenNext = CFGStmtVect[k]->next.size();
				int lenPrev = CFGStmtVect[k]->prev.size();
				std::cout<<"Stmt #"<<k<<" prev size: "<<lenPrev<<", next size: "<<lenNext<<std::endl;
				//std::cout<<"Stmt #"<<k<<", next size: "<<lenNext<<std::endl;
				if((lenNext == 1) && (lenPrev == 1))
				//if((lenNext == 1))
				{
					std::cout<<"Printing CFG entries ----------------------->>> "<<CFGStmtVect[k]->StmtID<<"     "<<CFGStmtVect[k]->InstructStmt<<"  NEXT ID:   "<<CFGStmtVect[k]->next[0]<<"  PREV ID:   "<<CFGStmtVect[k]->prev[0]<<std::endl;
				}
				if(lenNext > 1)
				{
					std::cout<<"Printing CFG entries ----------------------->>> "<<CFGStmtVect[k]->StmtID<<"     "<<CFGStmtVect[k]->InstructStmt<<std::endl;
					for(int i = 0; i<lenNext; i++){	
						std::cout<<"------ NEXT ID #"<<i+1<<" :   "<<CFGStmtVect[k]->next[i]<<std::endl;
					}
				}
				
				if(lenPrev > 1)
				{
					std::cout<<"Printing CFG entries ----------------------->>> "<<CFGStmtVect[k]->StmtID<<"     "<<CFGStmtVect[k]->InstructStmt<<std::endl;
					for(int i = 0; i<lenPrev; i++){	
						std::cout<<"------ PREV ID #"<<i+1<<" :   "<<CFGStmtVect[k]->prev[i]<<std::endl;
					}
				}

			}*/
			
			//Generating GEN & KILL sets
			CFGStmtVect = generateGenKill(CFGStmtVect);
			/*
			for(int k=0; k<CFGStmtVect.size(); k++){
				std::cout<<"Printing CFG entries ----------------------->>> "<<CFGStmtVect[k]->StmtID<<"     "<<CFGStmtVect[k]->InstructStmt<<std::endl;
				if(CFGStmtVect[k]->genSet.size() > 0){
					for(int a = 0; a < CFGStmtVect[k]->genSet.size(); a++){
						std::cout<<"GEN Set element #"<<a+1<<" --->  "<<CFGStmtVect[k]->genSet[a]<<std::endl;					
					}				
				}
				if(CFGStmtVect[k]->killSet.size() > 0){
					for(int a = 0; a < CFGStmtVect[k]->killSet.size(); a++){
						std::cout<<"KILL Set element #"<<a+1<<" --->  "<<CFGStmtVect[k]->killSet[a]<<std::endl;					
					}				
				}
			}*/

			//Computing Liveness
			do{

				CFGStmtVect = analyzeLiveness(CFGStmtVect);
				
			}while(isLivenessChanged);

			for(int k=0; k<CFGStmtVect.size(); k++){
				int inCount = 0;
				int outCount = 0;
				std::cout<<"Printing CFG entries ----------------------->>> "<<CFGStmtVect[k]->StmtID<<"     "<<CFGStmtVect[k]->InstructStmt<<std::endl;
				if(CFGStmtVect[k]->liveIN.size() > 0){
					std::cout<<"LIVE-IN size:   "<<CFGStmtVect[k]->liveIN.size()<<std::endl;
					for(std::set<std::string>::iterator a = CFGStmtVect[k]->liveIN.begin(); a != CFGStmtVect[k]->liveIN.end(); a++){
						inCount++;
						std::cout<<"LIVE IN element #"<<inCount<<" --->  "<<(*a)<<std::endl;					
					}				
				}
				if(CFGStmtVect[k]->liveOUT.size() > 0){
					std::cout<<"LIVE-OUT size:   "<<CFGStmtVect[k]->liveOUT.size()<<std::endl;
					for(std::set<std::string>::iterator a = CFGStmtVect[k]->liveOUT.begin(); a != CFGStmtVect[k]->liveOUT.end(); a++){
						outCount++;
						std::cout<<"LIVE OUT element #"<<outCount<<" --->  "<<(*a)<<std::endl;					
					}				
				}
			}//End of Liveliness computation

  
		    currVectTabTOP->IRtoAssembly(finalIRvector);  

                    delete((yyvsp[-4].sstr));
                  }
#line 1786 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 4:
#line 450 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.sstr) = new std::string(yytext);}
#line 1792 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 9:
#line 458 "src/parser.yy" /* yacc.c:1646  */
    { 
		    
                    Symbol * tmp = new Symbol(STRING, *(yyvsp[-3].sstr), *(yyvsp[-1].sstr));
		    
                    symtabStack.top()->addDecl(tmp);
		    

		    AssignNode* asnTempo = new AssignNode(*(yyvsp[-3].sstr), *(yyvsp[-1].sstr)); 
		    ASTNode* AsnAST = dynamic_cast<ASTNode*>(asnTempo); 

		    

                    delete((yyvsp[-3].sstr));
                    delete((yyvsp[-1].sstr));

                  }
#line 1813 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 10:
#line 476 "src/parser.yy" /* yacc.c:1646  */
    {
                    (yyval.sstr) = new std::string(yytext);

                  }
#line 1822 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 11:
#line 483 "src/parser.yy" /* yacc.c:1646  */
    {
		    
		    for(std::list<std::string>::iterator it=(*(yyvsp[-1].slist)).begin();it!=(*(yyvsp[-1].slist)).end();++it){  
		      //Symbol* tmp = new Symbol($1, id);  //CHRIS
		      Symbol* tmp = new Symbol((yyvsp[-2].tok), *it);

		     //OFFSET VALUE SETTING
		     tmp->symOffset = offset;
		     offset--;
		
			//std::cout<<tmp->var_name<<" offset:  "<<tmp->symOffset<<std::endl;

                      symtabStack.top()->addDecl(tmp);
			
			
                    }
                    delete((yyvsp[-1].slist));//delete list now we don't need it
                  }
#line 1845 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 12:
#line 502 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.tok) = FLOAT;}
#line 1851 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 13:
#line 502 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.tok) = INT;}
#line 1857 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 14:
#line 504 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.tok) = (yyvsp[0].tok);}
#line 1863 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 15:
#line 505 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.tok)= VOID;}
#line 1869 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 16:
#line 507 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.slist) = (yyvsp[0].slist); (yyval.slist)->push_front(*(yyvsp[-1].sstr)); delete((yyvsp[-1].sstr));}
#line 1875 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 17:
#line 509 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.slist) = (yyvsp[0].slist); (yyval.slist)->push_front(*(yyvsp[-1].sstr)); delete((yyvsp[-1].sstr));}
#line 1881 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 18:
#line 510 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.slist) = new std::list<std::string>;}
#line 1887 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 21:
#line 516 "src/parser.yy" /* yacc.c:1646  */
    {
                    Symbol *tmp = new Symbol((yyvsp[-1].tok), *(yyvsp[0].sstr));

		     //OFFSET VALUE SETTING
		    tmp->symOffset = offset;
		    offset++;

		    //std::cout<<tmp->var_name<<" offset:  "<<tmp->symOffset<<std::endl;		    
	
                    symtabStack.top()->addDecl(tmp);
		
	
                  }
#line 1905 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 26:
#line 536 "src/parser.yy" /* yacc.c:1646  */
    {
			    IRcodeVector.clear();
			    //Symbol Table
		            SymbolTable *func = new SymbolTable(*(yyvsp[-1].sstr), symtabStack.top());
		            symtabStack.top()->children.push_back(func);
			    //std::cout<<"symtabstack TOP scope  1    : "<<symtabStack.top()->scope<<std::endl;
			    //std::cout<<"printing var decl"<<std::endl;
			    if (printVDnum == 0){
				    symtabStack.top()->printVarDecl();  //Printing var decl
				    printVDnum = 1;
			    //std::cout<<"DONE printing var decl"<<std::endl;
			    }
		            symtabStack.push(func);
			    //std::cout<<"pushed function onto symtabStack"<<std::endl;
			    //Vector Table
			    VectorTable *vectFunc = new VectorTable(*(yyvsp[-1].sstr), vectTabStack.top());
			    vectTabStack.top()->vectChildren.push_back(vectFunc);
			    vectTabStack.push(vectFunc);
			    //std::cout<<"pushed vector table of function onto vectTabStack"<<std::endl;
			    //Global offset:
			    offset = 2;
                  }
#line 1932 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 27:
#line 559 "src/parser.yy" /* yacc.c:1646  */
    {//Global offset:
		    	offset = -1;
		  }
#line 1940 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 28:
#line 563 "src/parser.yy" /* yacc.c:1646  */
    {
			VectorTable* currVectTabTOP = vectTabStack.top();
			currVectTabTOP->stmt_listPtrVect = (yyvsp[0].ASTPtrVectPtr);
			
			//std::cout<<"Function: "<<currVectTabTOP->vectTabName<<std::endl;

			//std::cout<<"Calling stack iterator for ir"<<std::endl;
			currVectTabTOP->entireTable = symtabStack.top();
			SymbolTable* symTab = symtabStack.top();
		        std::vector<CodeObject*> vect = currVectTabTOP->StackIteratorforIR(coVect,currVectTabTOP->vectTabName,symtabStack.top());
			//std::cout<<"PRINTING IR VECT NOW"<<std::endl;

			//BEGINNING IR code statements
			
			//currVectTabTOP->finalIRstringVector.insert(currVectTabTOP->finalIRstringVector.begin(),";LINK 1");	  ///Instead of hardcoding, just put in number of local args for func

			int numLocalArgs = 0;
			for (int k = 0; k<(symTab->ordered_table).size(); k++){
				if ((symTab->ordered_table)[k]->symOffset < 0){
					//std::cout<<(symTab->ordered_table)[k]->var_name<<std::endl;
					numLocalArgs++;
				}
			}
			//std::cout<<"Local args: "<<numLocalArgs<<std::endl;
			std::stringstream ss;
			ss << numLocalArgs;
			std::string strNum(ss.str());
			strNum = ";LINK "+strNum;
			currVectTabTOP->finalIRstringVector.insert(currVectTabTOP->finalIRstringVector.begin(),strNum);	  ///Instead of hardcoding, just put in number of local args for func



			//function name label
			std::string funcLabel;

			//std::cout<<"Now adding label for:  "<<currVectTabTOP->vectTabName<<std::endl;
			funcLabel = funcLabel + ";LABEL FUNC_"+currVectTabTOP->vectTabName;
			//std::cout<<"funclabel is :  "<<funcLabel<<std::endl;
			currVectTabTOP->finalIRstringVector.insert(currVectTabTOP->finalIRstringVector.begin(),funcLabel);
			
			//std::cout<<"Printing first element of vector: should be function label : "<<currVectTabTOP->finalIRstringVector[0]<<std::endl;			
	
			//currVectTabTOP->finalIRstringVector.insert(currVectTabTOP->finalIRstringVector.begin(),";HALT");
			/*
			std::string funcJsr;
			funcJsr = funcJsr + ";JSR FUNC_"+currVectTabTOP->vectTabName; 
			currVectTabTOP->finalIRstringVector.insert(currVectTabTOP->finalIRstringVector.begin(),funcJsr);

			currVectTabTOP->finalIRstringVector.insert(currVectTabTOP->finalIRstringVector.begin(),";PUSHREGS");
			currVectTabTOP->finalIRstringVector.insert(currVectTabTOP->finalIRstringVector.begin(),";PUSH");			
			currVectTabTOP->finalIRstringVector.insert(currVectTabTOP->finalIRstringVector.begin(),";IR CODE");			
			*/			
			currVectTabTOP->finalIRstringVector.push_back(";UNLINK");			
			currVectTabTOP->finalIRstringVector.push_back(";RET");			
			
			
			//currVectTabTOP->PrintIRcodeVector(currVectTabTOP->finalIRstringVector);  
			//finalIRvector = currVectTabTOP->finalIRstringVector;     //trying to split function wise and then have 1 main vector
			tempIRvector = currVectTabTOP->finalIRstringVector;
			/*
			std::cout<<"<<<<<<<<<<<<<<< PRINTING tempIRvector now >>>>>>>>>>>>>>>>"<<std::endl;
			for (int it = 0; it < tempIRvector.size(); it++){
				std::cout<<tempIRvector[it]<<std::endl;
			}
			std::cout<<"<<<<<<<<<<<<<<< DONE PRINTING tempIRvector >>>>>>>>>>>>>>>>"<<std::endl;
			*/			
			//currVectTabTOP->IRtoAssembly(currVectTabTOP->finalIRstringVector);  
			/*
			std::cout<<"<<<<<<<<<<<<<<< PRINTING IRcodeVector now >>>>>>>>>>>>>>>>"<<std::endl;
			for (int it = 0; it < IRcodeVector.size(); it++){
				std::cout<<IRcodeVector[it]<<std::endl;
			}
			std::cout<<"<<<<<<<<<<<<<<< DONE PRINTING IRcodeVector >>>>>>>>>>>>>>>>"<<std::endl;
			*/

			finalIRvector.insert(finalIRvector.end(), tempIRvector.begin(), tempIRvector.end());

			

		  }
#line 2025 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 29:
#line 643 "src/parser.yy" /* yacc.c:1646  */
    {
                    symtabStack.pop(); //Symbol Table		    
		    vectTabStack.pop(); //Vector Table
                  }
#line 2034 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 30:
#line 648 "src/parser.yy" /* yacc.c:1646  */
    {
			 (yyval.ASTPtrVectPtr) = (yyvsp[0].ASTPtrVectPtr);
		}
#line 2042 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 31:
#line 656 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtrVectPtr) = (yyvsp[0].ASTPtrVectPtr); (yyval.ASTPtrVectPtr)->insert((yyval.ASTPtrVectPtr)->begin(), (yyvsp[-1].ASTPtr)); }
#line 2048 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 32:
#line 657 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtrVectPtr) = new std::vector<ASTNode*>;}
#line 2054 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 33:
#line 659 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr);}
#line 2060 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 34:
#line 660 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr); }
#line 2066 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 35:
#line 663 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr); }
#line 2072 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 36:
#line 666 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr);}
#line 2078 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 37:
#line 667 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr);
					
			      }
#line 2086 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 38:
#line 670 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr);
				
             		}
#line 2094 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 39:
#line 673 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr);}
#line 2100 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 40:
#line 676 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[-1].ASTPtr);}
#line 2106 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 41:
#line 678 "src/parser.yy" /* yacc.c:1646  */
    {
					//printInOrder($3); 
					AssignNode* asnTempo = new AssignNode(*(yyvsp[-2].sstr), (yyvsp[0].ASTPtr)); 
					ASTNode* AsnAST = dynamic_cast<ASTNode*>(asnTempo); 

					VectorTable* currVectTabTop = vectTabStack.top();
					(currVectTabTop->stmtVect).push_back(AsnAST);

					//Assigning type to assign_expr
					(yyval.ASTPtr) = AsnAST; 
					//$$ = NULL;										
					}
#line 2123 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 42:
#line 693 "src/parser.yy" /* yacc.c:1646  */
    {
			(yyval.ASTPtr) = new ASTNode(); //Master ASTNode for IO creation  **************************************************************************************
			(yyval.ASTPtr)->IOType = "READ";

			for(std::list<std::string>::iterator it=(*(yyvsp[-2].slist)).begin();it!=(*(yyvsp[-2].slist)).end();++it) 
			{
			   //if stmt to check for newline
			   if(*it == "newline"){
				

				IONode *tempo = new IONode (NULL, "READ"); //IONode creation
		                ASTNode *ASTtempo = dynamic_cast<ASTNode*>(tempo);
				

				VectorTable* currVectTabTop = vectTabStack.top();
				(currVectTabTop->stmtVect).push_back(ASTtempo);
				(yyval.ASTPtr)->IOIdVect.push_back(ASTtempo);
				
				} //end of if - newline
			   else{
			      
			      SymbolTable* currentTab;
		              currentTab = symtabStack.top();
		              while(currentTab != NULL){

		                if(currentTab->table.find(*it) == currentTab->table.end()){
		                  if(currentTab->scope == "GLOBAL"){
				
		                    std::cout<<"EXPRESSION ERROR"<<"\n"; //needs help
		              exit(1);
		                  }

		                } //end of if
		                else{

		                  for (int i = 0; i< currentTab->ordered_table.size(); i++){
		                    if (currentTab->ordered_table[i]->var_name == *it){
				      			     
		                      IONode *tempo = new IONode (currentTab->ordered_table[i], "READ"); //IONode creation
		                      ASTNode *ASTtempo = dynamic_cast<ASTNode*>(tempo);
				      
				      VectorTable* currVectTabTop = vectTabStack.top();
				      (currVectTabTop->stmtVect).push_back(ASTtempo);
				      
				      (yyval.ASTPtr)->IOIdVect.push_back(ASTtempo); 	//Adding to Master IO ASTNode IOIdVect *******************************************************				
				     
		                    }
		                  }
		                  break;    
                      
		                } //end of else

		                currentTab = currentTab->parent;

		              } //end of while
			} //end of else - newline
		     }//end of for
		   	
		    }
#line 2187 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 43:
#line 755 "src/parser.yy" /* yacc.c:1646  */
    { 
			(yyval.ASTPtr) = new ASTNode(); //Master ASTNode for IO creation  **************************************************************************************
			(yyval.ASTPtr)->IOType = "WRITE";

			for(std::list<std::string>::iterator it=(*(yyvsp[-2].slist)).begin();it!=(*(yyvsp[-2].slist)).end();++it) 
			{
			   //"newline" case
			   if(*it == "newline"){
				

				IONode *tempo = new IONode (NULL, "WRITE"); //IONode creation
		                ASTNode *ASTtempo = dynamic_cast<ASTNode*>(tempo);
				

				VectorTable* currVectTabTop = vectTabStack.top();
				(currVectTabTop->stmtVect).push_back(ASTtempo);

				(yyval.ASTPtr)->IOIdVect.push_back(ASTtempo);

				} //end of if - newline
			   
			  //Symbols
			  else{
			      //if stmt to check for newline
			      SymbolTable* currentTab;
		              currentTab = symtabStack.top();
		              while(currentTab != NULL){

		                if(currentTab->table.find(*it) == currentTab->table.end()){
		                  if(currentTab->scope == "GLOBAL"){
				    std::cout<<"I am in WRITE"<<"\n"<<std::endl;
		                    std::cout<<"EXPRESSION ERROR"<<"\n"; //needs help
		              exit(1);
		                  }

		                } //end of if
		                else{
		                  //std::cout<<currentTab->scope<<std::endl;
		                  for (int i = 0; i< currentTab->ordered_table.size(); i++){
		                    if (currentTab->ordered_table[i]->var_name == *it){			      
				      
				      
		                      IONode *tempo = new IONode (currentTab->ordered_table[i], "WRITE"); //IONode creation
		                      ASTNode *ASTtempo = dynamic_cast<ASTNode*>(tempo);
				      

				      VectorTable* currVectTabTop = vectTabStack.top();
				      (currVectTabTop->stmtVect).push_back(ASTtempo);				      

					(yyval.ASTPtr)->IOIdVect.push_back(ASTtempo); //Adding to Master IO ASTNode IOIdVect *******************************************************
				     
		                    }
		                  }
		                  break;                          
		                } //end of else
		                currentTab = currentTab->parent;
		              } //end of while
			} //end of else - newline
		     }//end of for
			
		   }
#line 2253 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 44:
#line 822 "src/parser.yy" /* yacc.c:1646  */
    {ReturnNode* retnTempo = new ReturnNode((yyvsp[-1].ASTPtr)); (yyval.ASTPtr) = dynamic_cast<ASTNode*>(retnTempo);}
#line 2259 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 45:
#line 826 "src/parser.yy" /* yacc.c:1646  */
    {
			(yyval.ASTPtr) = (yyvsp[-1].ASTPtr);
			if((yyvsp[-1].ASTPtr) == NULL)
			{
				(yyval.ASTPtr) = (yyvsp[0].ASTPtr);
			
			}
			else
			{
				//$$->leftChild = $1;
				(yyval.ASTPtr)->rightChild = (yyvsp[0].ASTPtr);
			}
		}
#line 2277 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 46:
#line 840 "src/parser.yy" /* yacc.c:1646  */
    {
			(yyval.ASTPtr) = (yyvsp[0].ArithPtr);
			if((yyvsp[-2].ASTPtr) == NULL)
			{
				(yyvsp[0].ArithPtr)->leftChild = (yyvsp[-1].ASTPtr);
				(yyvsp[0].ArithPtr)->rightChild = NULL;
			
			}
			else
			{
				(yyvsp[0].ArithPtr)->leftChild = (yyvsp[-2].ASTPtr);
				(yyvsp[0].ArithPtr)->leftChild->rightChild = (yyvsp[-1].ASTPtr);
				(yyvsp[0].ArithPtr)->rightChild = NULL;
			}
			
		     }
#line 2298 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 47:
#line 857 "src/parser.yy" /* yacc.c:1646  */
    { (yyval.ASTPtr) = NULL; }
#line 2304 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 48:
#line 860 "src/parser.yy" /* yacc.c:1646  */
    {
			(yyval.ASTPtr) = (yyvsp[-1].ASTPtr);
			if((yyvsp[-1].ASTPtr) == NULL)
			{
				(yyval.ASTPtr) = (yyvsp[0].ASTPtr);
			
			}
			else
			{
				//$$->leftChild = $1;
				(yyval.ASTPtr)->rightChild = (yyvsp[0].ASTPtr);
			}
		}
#line 2322 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 49:
#line 874 "src/parser.yy" /* yacc.c:1646  */
    {
			(yyval.ASTPtr) = dynamic_cast<ASTNode*>(yyvsp[0].ArithPtr);
			if((yyvsp[-2].ASTPtr) == NULL)
			{
				(yyval.ASTPtr)->leftChild = (yyvsp[-1].ASTPtr);
				(yyval.ASTPtr)->rightChild = NULL;
			
			}
			else
			{
				(yyval.ASTPtr)->leftChild = (yyvsp[-2].ASTPtr);
				(yyval.ASTPtr)->leftChild->rightChild = (yyvsp[-1].ASTPtr);
				(yyval.ASTPtr)->rightChild = NULL;
			}
			
		     }
#line 2343 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 50:
#line 890 "src/parser.yy" /* yacc.c:1646  */
    { (yyval.ASTPtr) = NULL; }
#line 2349 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 51:
#line 892 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr);}
#line 2355 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 52:
#line 892 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr);}
#line 2361 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 53:
#line 895 "src/parser.yy" /* yacc.c:1646  */
    {
			//std::cout<<"-------------------  CALL EXPR IS CALLED -------------------------"<<std::endl;
			CallExprNode* callnTempo = new CallExprNode((yyvsp[-1].ASTPtrVectPtr), (yyvsp[-3].sstr));
			(yyval.ASTPtr) = dynamic_cast<ASTNode*>(callnTempo); 
		    }
#line 2371 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 54:
#line 901 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtrVectPtr) = (yyvsp[0].ASTPtrVectPtr); (yyval.ASTPtrVectPtr)->insert((yyval.ASTPtrVectPtr)->begin(), (yyvsp[-1].ASTPtr));}
#line 2377 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 55:
#line 901 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtrVectPtr) = NULL;}
#line 2383 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 56:
#line 902 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtrVectPtr) = (yyvsp[0].ASTPtrVectPtr); (yyval.ASTPtrVectPtr)->insert((yyval.ASTPtrVectPtr)->begin(), (yyvsp[-1].ASTPtr));}
#line 2389 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 57:
#line 903 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtrVectPtr) = new std::vector<ASTNode*>;}
#line 2395 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 58:
#line 905 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[-1].ASTPtr);}
#line 2401 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 59:
#line 906 "src/parser.yy" /* yacc.c:1646  */
    {
			
                      SymbolTable* currentTab;
                      currentTab = symtabStack.top();
                      while(currentTab != NULL){
                        if(currentTab->table.find(*(yyvsp[0].sstr)) == currentTab->table.end()){
                         if(currentTab->scope == "GLOBAL"){
			    std::cout<<"I am primary"<<std::endl;
                            std::cout<<"PRIMARY ERROR"<<"\n"; //needs help
                      exit(1);
                          }

                        }
                        else{
			
                          //std::cout<<currentTab->scope<<std::endl;
                          for (int i = 0; i< currentTab->ordered_table.size(); i++){
                            if (currentTab->ordered_table[i]->var_name == *(yyvsp[0].sstr)){

                              VarRef *tempo = new VarRef (currentTab->ordered_table[i]);
                              ASTNode *ASTtempo = dynamic_cast<ASTNode*>(tempo);
                              (yyval.ASTPtr) = ASTtempo;

                            }
                          }
                          break;                          
                        }
                        currentTab = currentTab->parent;
                      }
                    }
#line 2436 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 60:
#line 937 "src/parser.yy" /* yacc.c:1646  */
    {
			LitNode *tempo = new LitNode(std::string(yytext), 5);
			ASTNode *ASTtempo = dynamic_cast<ASTNode*>(tempo);			
			(yyval.ASTPtr) = ASTtempo;
			
			}
#line 2447 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 61:
#line 943 "src/parser.yy" /* yacc.c:1646  */
    {
			LitNode *tempo = new LitNode(std::string(yytext), 6);
			ASTNode *ASTtempo = dynamic_cast<ASTNode*>(tempo);			
			(yyval.ASTPtr) = ASTtempo;
			
			}
#line 2458 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 62:
#line 950 "src/parser.yy" /* yacc.c:1646  */
    {Arithmetic* op = new Arithmetic("+"); (yyval.ArithPtr) = op; }
#line 2464 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 63:
#line 951 "src/parser.yy" /* yacc.c:1646  */
    {Arithmetic* op = new Arithmetic("-"); (yyval.ArithPtr) = op; }
#line 2470 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 64:
#line 952 "src/parser.yy" /* yacc.c:1646  */
    {Arithmetic* op = new Arithmetic("*"); (yyval.ArithPtr) = op; }
#line 2476 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 65:
#line 953 "src/parser.yy" /* yacc.c:1646  */
    {Arithmetic* op = new Arithmetic("/"); (yyval.ArithPtr) = op; }
#line 2482 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 66:
#line 957 "src/parser.yy" /* yacc.c:1646  */
    { 
		    
                    SymbolTable *block = new SymbolTable(genScope(), symtabStack.top());
                    symtabStack.top()->children.push_back(block);
                    symtabStack.push(block);
                    /*Create */	
		    //std::cout<<"If being detected!"<<std::endl;
		    ++ifCounter; 
		
                  }
#line 2497 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 67:
#line 967 "src/parser.yy" /* yacc.c:1646  */
    {
                    symtabStack.pop();//pop off the if block
		    
                    SymbolTable *block = new SymbolTable(genScope(), symtabStack.top());
                    symtabStack.top()->children.push_back(block);
                    symtabStack.push(block);
                    /*Pop, Create */
                  }
#line 2510 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 68:
#line 976 "src/parser.yy" /* yacc.c:1646  */
    {	
			(yyval.ASTPtr) = new If_ElseNode((yyvsp[-7].ASTPtr), (yyvsp[-3].ASTPtrVectPtr), (yyvsp[-1].ASTPtrVectPtr));
			//std::cout<<"LINE: "<<__LINE__<<"\n";
			(yyval.ASTPtr)->If_ElseType = "IF";	  		    		
			//$$ = globalIfNodeTEMP;
			symtabStack.pop();
                      }
#line 2522 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 69:
#line 985 "src/parser.yy" /* yacc.c:1646  */
    {/*std::cout<<"Else being detected!"<<std::endl;*/ ++elseCounter;}
#line 2528 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 70:
#line 986 "src/parser.yy" /* yacc.c:1646  */
    { (yyval.ASTPtrVectPtr) = (yyvsp[0].ASTPtrVectPtr);}
#line 2534 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 71:
#line 987 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtrVectPtr) = NULL;}
#line 2540 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 72:
#line 990 "src/parser.yy" /* yacc.c:1646  */
    {
				CondNode* condObj = new CondNode((yyvsp[-2].ASTPtr), *(yyvsp[-1].sstr), "\0", (yyvsp[0].ASTPtr));
				(yyval.ASTPtr) = dynamic_cast<ASTNode*>(condObj); 
			}
#line 2549 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 73:
#line 995 "src/parser.yy" /* yacc.c:1646  */
    {
				CondNode* condObj = new CondNode(NULL, "\0", "TRUE", NULL);
				(yyval.ASTPtr) = dynamic_cast<ASTNode*>(condObj); 
			}
#line 2558 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 74:
#line 1001 "src/parser.yy" /* yacc.c:1646  */
    {
				CondNode* condObj = new CondNode(NULL, "\0", "FALSE", NULL);
				(yyval.ASTPtr) = dynamic_cast<ASTNode*>(condObj); 
			}
#line 2567 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 75:
#line 1006 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.sstr) = new std::string(yytext);}
#line 2573 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 76:
#line 1007 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.sstr) = new std::string(yytext);}
#line 2579 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 77:
#line 1008 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.sstr) = new std::string(yytext);}
#line 2585 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 78:
#line 1009 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.sstr) = new std::string(yytext);}
#line 2591 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 79:
#line 1010 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.sstr) = new std::string(yytext);}
#line 2597 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 80:
#line 1011 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.sstr) = new std::string(yytext);}
#line 2603 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 81:
#line 1015 "src/parser.yy" /* yacc.c:1646  */
    {
                    //symtabStack.pop();//pop off the if block
		    
                    SymbolTable *block = new SymbolTable(genScope(), symtabStack.top());
                    symtabStack.top()->children.push_back(block);
                    symtabStack.push(block);
                    /*Pop, Create */
                  }
#line 2616 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 82:
#line 1024 "src/parser.yy" /* yacc.c:1646  */
    {
		    (yyval.ASTPtr) = new WhileNode((yyvsp[-5].ASTPtr), (yyvsp[-1].ASTPtrVectPtr));
		    //std::cout<<"LINE: "<<__LINE__<<"\n";		    
                    symtabStack.pop();
                  }
#line 2626 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 83:
#line 1032 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr);}
#line 2632 "generated/parser.cpp" /* yacc.c:1646  */
    break;

  case 84:
#line 1033 "src/parser.yy" /* yacc.c:1646  */
    {(yyval.ASTPtr) = (yyvsp[0].ASTPtr);}
#line 2638 "generated/parser.cpp" /* yacc.c:1646  */
    break;


#line 2642 "generated/parser.cpp" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 1037 "src/parser.yy" /* yacc.c:1906  */

