#include<iostream>
#include <string>
#include <stack>
#include <vector>
#include "Symbol.h"

void Symbol::setStrValue(std::string str_val) {
	this->str_var_value = str_val;
}
